import { test, expect } from '../fixtures/testFixtures';
import { employeeData } from '../testdata/employeeData';
import { createLogger } from '../utils/logger';
const logger = createLogger('AddEmployeeTest');
import path from 'path';

test('Admin can add an employee from PIM with image', async ({
  page,
  loginPage,
  dashboardPage,
  employeePage
}) => {
  logger.info('========== TEST STARTED ==========');
  const imagePath = path.resolve(
    process.cwd(),
    'src',
    'fixtures',
    'images',
    'Mypic.jpg');
  await loginPage.open();
  await loginPage.login();

  await dashboardPage.openPIM();
  await employeePage.openAddEmployee();
  await employeePage.addEmployee(
    employeeData.firstName,
    employeeData.lastName,
    employeeData.middleName
  );

  await expect(page.getByText(employeeData.firstName, { exact: false })).toBeVisible();
  logger.info('Employee creation test passed');
  logger.info('========== TEST COMPLETED ==========');
});


/*
npx playwright test addEmployee.spec.ts --headed
View the reports
Report	Command
HTML	npx playwright show-report
Allure	allure generate allure-results --clean -o allure-report
Open Allure	allure open allure-report
Custom	Check the output path configured in CustomReporter.ts
*/