import { test as base } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { DashboardPage } from '../pages/DashboardPage';
import { ViewEmployeeListPage } from '../pages/ViewEmployeeListPage';

type FrameworkFixtures = {
  loginPage: LoginPage;
  dashboardPage: DashboardPage;
  employeePage: ViewEmployeeListPage;
};

export const test = base.extend<FrameworkFixtures>({
  loginPage: async ({ page }, use) => use(new LoginPage(page)),
  dashboardPage: async ({ page }, use) => use(new DashboardPage(page)),
  employeePage: async ({ page }, use) => use(new ViewEmployeeListPage(page))
});

export { expect } from '@playwright/test';
